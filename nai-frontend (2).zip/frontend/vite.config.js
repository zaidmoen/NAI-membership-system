import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The dev proxy keeps API calls same-origin, so the backend needs no CORS settings
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': 'http://127.0.0.1:8000',
    },
  },
  test: {
    environment: 'node',
  },
})

import { ApiError, postJson } from './client'

// The backend has no administrator login API yet
// It only has the Django admin page at /admin/ and session authentication for the
// staff-only student endpoints. Put the real endpoint here once it exists
export const LOGIN_ENDPOINT = null

// Django users sign in with a username by default
// Change the field name here if the future endpoint uses email
export const IDENTIFIER_FIELD = 'username'

export function loginAdmin({ identifier, password }) {
  if (!LOGIN_ENDPOINT) {
    return Promise.reject(new ApiError('unavailable'))
  }
  return postJson(LOGIN_ENDPOINT, { [IDENTIFIER_FIELD]: identifier.trim(), password })
}

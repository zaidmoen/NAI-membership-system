import { postJson } from './client'

// Existing endpoint: POST /api/students/register/
export const REGISTER_ENDPOINT = '/api/students/register/'

// The backend currently accepts only full_name and university_id
// Set a field to true once the backend serializer supports it, and check the
// backend field name first because "major" and "whatsapp" are placeholders
export const BACKEND_FIELDS = {
  full_name: { supported: true, backendName: 'full_name' },
  university_id: { supported: true, backendName: 'university_id' },
  major: { supported: false, backendName: 'major' },
  whatsapp: { supported: false, backendName: 'whatsapp' },
}

// Build the request body from the form values, skipping fields the backend does not know yet
export function buildRegistrationPayload(values) {
  const payload = {}
  for (const [key, config] of Object.entries(BACKEND_FIELDS)) {
    if (config.supported) payload[config.backendName] = values[key].trim()
  }
  return payload
}

// Turn backend error keys back into form field keys
export function mapBackendErrors(data) {
  const errors = {}
  if (!data || typeof data !== 'object') return errors
  for (const [key, config] of Object.entries(BACKEND_FIELDS)) {
    const messages = data[config.backendName]
    if (messages) errors[key] = [].concat(messages).join(' ')
  }
  return errors
}

export function registerStudent(values) {
  return postJson(REGISTER_ENDPOINT, buildRegistrationPayload(values))
}

import { Navigate, Route, Routes } from 'react-router-dom'
import MembershipRegistrationPage from './pages/MembershipRegistrationPage'
import AdminLoginPage from './pages/AdminLoginPage'

export default function App() {
  return (
    <Routes>
      <Route path="/register" element={<MembershipRegistrationPage />} />
      <Route path="/admin/login" element={<AdminLoginPage />} />
      <Route path="*" element={<Navigate to="/register" replace />} />
    </Routes>
  )
}

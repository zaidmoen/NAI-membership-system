import { useState } from 'react'
import AuthShell from '../components/AuthShell'
import Field from '../components/Field'
import Alert from '../components/Alert'
import { LockIcon, ShieldIcon, UserIcon } from '../components/Icons'
import { loginAdmin } from '../api/authApi'
import { validateLogin } from '../utils/validation'

export default function AdminLoginPage() {
  const [values, setValues] = useState({ identifier: '', password: '' })
  const [errors, setErrors] = useState({})
  const [formError, setFormError] = useState('')
  const [loading, setLoading] = useState(false)
  const [signedIn, setSignedIn] = useState(false)

  const handleChange = (event) => {
    const { name, value } = event.target
    setValues((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }))
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setFormError('')

    const clientErrors = validateLogin(values)
    setErrors(clientErrors)
    if (Object.keys(clientErrors).length > 0) return

    setLoading(true)
    try {
      await loginAdmin(values)
      // Redirect to the dashboard here once that page exists
      setSignedIn(true)
    } catch (err) {
      if (err.kind === 'unauthorized' || err.kind === 'validation') {
        setFormError('اسم المستخدم أو كلمة المرور غير صحيحة')
      } else if (err.kind === 'network') {
        setFormError('تعذر الاتصال بالخادم، تحقق من اتصالك بالإنترنت وحاول مرة أخرى')
      } else if (err.kind === 'unavailable') {
        setFormError('تسجيل الدخول غير متاح حاليًا، لم تتم إضافة واجهة المصادقة في الخادم بعد')
      } else {
        setFormError('حدث خطأ غير متوقع، حاول مرة أخرى لاحقًا')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthShell
      variant="admin"
      title="لوحة إدارة العضوية"
      subtitle="منطقة مخصصة لمسؤولي الجمعية فقط"
    >
      <div className="card__icon card__icon--secure"><ShieldIcon /></div>
      <h2 id="card-title" className="card__title">تسجيل دخول المسؤول</h2>
      <p className="card__subtitle">أدخل بيانات حسابك للمتابعة</p>

      {signedIn ? (
        <p className="notice notice--ok" role="status">تم تسجيل الدخول بنجاح.</p>
      ) : (
        <form onSubmit={handleSubmit} noValidate>
          {formError && <Alert>{formError}</Alert>}

          <Field label="اسم المستخدم" icon={<UserIcon />} name="identifier" value={values.identifier}
            onChange={handleChange} error={errors.identifier} placeholder="أدخل اسم المستخدم" ltr autoComplete="username" />
          <Field label="كلمة المرور" icon={<LockIcon />} name="password" type="password" value={values.password}
            onChange={handleChange} error={errors.password} placeholder="أدخل كلمة المرور" ltr autoComplete="current-password" />

          <button className="btn btn--primary" type="submit" disabled={loading}>
            {loading ? 'جارٍ تسجيل الدخول...' : 'تسجيل الدخول'}
          </button>
        </form>
      )}
    </AuthShell>
  )
}
